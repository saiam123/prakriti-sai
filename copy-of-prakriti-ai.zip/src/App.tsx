/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { 
  Heart, 
  User, 
  Activity, 
  MapPin, 
  Scale, 
  Droplets, 
  Wind, 
  Brain, 
  Stethoscope,
  Leaf,
  AlertCircle,
  CheckCircle2,
  Loader2,
  FileText,
  BookOpen,
  Search,
  ChevronRight,
  Utensils,
  Clock,
  Plus,
  Trash2,
  Coffee,
  Moon,
  Sun,
  TreePine,
  Sprout,
  Signature,
  Ruler,
  Weight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import { 
  LineChart,
  Line,
  PieChart, 
  Pie, 
  Cell, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  ZAxis
} from 'recharts';
import { Type } from "@google/genai";
import { format } from 'date-fns';

// Initialize Gemini API
const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

interface UserData {
  name: string;
  gender: string;
  age: string;
  location: string;
  height: string;
  weight: string;
  bmi: string;
  bp: string;
  cholesterol: string;
  sugar: string;
  pulse: string;
  thyroid: string;
  smoking: string;
  asthma: string;
  stress: string;
  sleepHours: string;
  sleepQuality: string;
  symptoms: string;
  selectedSymptoms: { name: string; severity: 'Low' | 'Medium' | 'High' }[];
  foodJournal: { type: string; time: string; ingredients: string; portion: string }[];
  prediction: string;
}

const SYMPTOMS_LIST = [
  { name: 'Dry Skin', dosha: 'Vata' },
  { name: 'Constipation', dosha: 'Vata' },
  { name: 'Anxiety', dosha: 'Vata' },
  { name: 'Insomnia', dosha: 'Vata' },
  { name: 'Joint Pain', dosha: 'Vata' },
  { name: 'Heartburn', dosha: 'Pitta' },
  { name: 'Anger/Irritability', dosha: 'Pitta' },
  { name: 'Skin Rashes', dosha: 'Pitta' },
  { name: 'Excessive Thirst', dosha: 'Pitta' },
  { name: 'Inflammation', dosha: 'Pitta' },
  { name: 'Weight Gain', dosha: 'Kapha' },
  { name: 'Lethargy', dosha: 'Kapha' },
  { name: 'Congestion', dosha: 'Kapha' },
  { name: 'Slow Digestion', dosha: 'Kapha' },
  { name: 'Oily Skin', dosha: 'Kapha' },
  { name: 'Fatigue', dosha: 'General' },
  { name: 'Headache', dosha: 'General' },
  { name: 'Indigestion', dosha: 'General' },
];

interface EducationalItem {
  title: string;
  description: string;
  category: 'Concept' | 'Herb' | 'Practice';
}

interface ReportData {
  markdown: string;
  doshaData: { name: string; value: number }[];
  locationDiseaseData: { name: string; value: number }[];
  dietData: { name: string; value: number }[];
  medicineData: { name: string; value: number }[];
  pranayama: { 
    name: string; 
    benefit: string; 
    detailedBenefits: string[];
    steps: string[];
    duration: string;
    bestTime: string;
  }[];
  educationalContent: EducationalItem[];
}

interface HistoryEntry {
  id: string;
  date: string;
  formData: UserData;
  reportData: ReportData;
}

const initialData: UserData = {
  name: '',
  gender: 'Male',
  age: '',
  location: '',
  height: '',
  weight: '',
  bmi: '',
  bp: '',
  cholesterol: '',
  sugar: '',
  pulse: '',
  thyroid: 'No',
  smoking: 'No',
  asthma: 'No',
  stress: 'Low',
  sleepHours: '',
  sleepQuality: 'Good',
  symptoms: '',
  selectedSymptoms: [],
  foodJournal: [],
  prediction: ''
};

const GLOSSARY_TERMS = [
  { term: 'Vata', definition: 'The energy of movement, composed of space and air. It governs breathing, blinking, muscle and tissue movement, and heart pulsation.', category: 'Dosha' },
  { term: 'Pitta', definition: 'The energy of digestion and metabolism, composed of fire and water. It governs digestion, absorption, assimilation, nutrition, metabolism, and body temperature.', category: 'Dosha' },
  { term: 'Kapha', definition: 'The energy of lubrication and structure, composed of earth and water. It forms the body\'s structures—bones, muscles, tendons—and provides the "glue" that holds the cells together.', category: 'Dosha' },
  { term: 'Ashwagandha', definition: 'An adaptogenic herb known for its ability to help the body manage stress, boost energy levels, and improve concentration.', category: 'Herb' },
  { term: 'Turmeric (Haridra)', definition: 'A powerful anti-inflammatory and antioxidant herb used widely for skin health, digestion, and immunity.', category: 'Herb' },
  { term: 'Triphala', definition: 'A traditional Ayurvedic herbal formulation consisting of three fruits: Amalaki, Bibhitaki, and Haritaki. It is primarily used for digestive health and detoxification.', category: 'Herb' },
  { term: 'Brahmi', definition: 'A renowned herb for brain health, memory enhancement, and reducing anxiety.', category: 'Herb' },
  { term: 'Tulsi (Holy Basil)', definition: 'Considered the "Queen of Herbs," it is used for respiratory health, stress relief, and boosting immunity.', category: 'Herb' },
  { term: 'Pranayama', definition: 'The practice of breath control in yoga, aimed at increasing vital life force (Prana) and calming the mind.', category: 'Practice' },
  { term: 'Abhyanga', definition: 'A form of Ayurvedic therapy that involves massage of the entire body from the head to the toes with warm oil.', category: 'Practice' },
  { term: 'Dinacharya', definition: 'The Ayurvedic daily routine designed to maintain health and prevent disease by aligning with the natural cycles of the day.', category: 'Practice' },
  { term: 'Panchakarma', definition: 'A comprehensive Ayurvedic detoxification and rejuvenation program consisting of five therapeutic actions.', category: 'Practice' },
  { term: 'Ojas', definition: 'The vital energy or "essence" that provides strength, immunity, and happiness. It is the end product of perfect digestion.', category: 'Concept' },
  { term: 'Agni', definition: 'The biological fire that governs metabolism and digestion. Strong Agni is essential for good health.', category: 'Concept' },
  { term: 'Ama', definition: 'Toxic byproduct of incomplete digestion. It is considered the root cause of many diseases in Ayurveda.', category: 'Concept' },
  { term: 'Prakriti', definition: 'An individual\'s unique physical and mental constitution, determined at the time of conception.', category: 'Concept' },
];

const AyurvedicGlossary = ({ theme }: { theme: 'light' | 'dark' }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState<'All' | 'Dosha' | 'Herb' | 'Practice' | 'Concept'>('All');

  const filteredTerms = GLOSSARY_TERMS.filter(item => {
    const matchesSearch = item.term.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          item.definition.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === 'All' || item.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const categories: ('All' | 'Dosha' | 'Herb' | 'Practice' | 'Concept')[] = ['All', 'Dosha', 'Herb', 'Practice', 'Concept'];

  return (
    <div className={`mt-12 p-8 rounded-3xl border transition-colors ${
      theme === 'light' ? 'bg-white border-emerald-100' : 'bg-slate-800/50 border-slate-700'
    }`}>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-lg ${theme === 'light' ? 'bg-emerald-100 text-emerald-600' : 'bg-emerald-500/20 text-emerald-400'}`}>
            <Search className="w-6 h-6" />
          </div>
          <h2 className={`text-2xl font-bold m-0 border-none transition-colors ${
            theme === 'light' ? 'text-emerald-900' : 'text-emerald-100'
          }`}>Ayurvedic Glossary</h2>
        </div>

        <div className="flex flex-wrap gap-2">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all ${
                activeCategory === cat
                  ? (theme === 'light' ? 'bg-emerald-600 text-white' : 'bg-emerald-500 text-slate-950')
                  : (theme === 'light' ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100' : 'bg-slate-700 text-slate-300 hover:bg-slate-600')
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="relative mb-8">
        <Search className={`absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 ${theme === 'light' ? 'text-emerald-400' : 'text-slate-500'}`} />
        <input
          type="text"
          placeholder="Search terms or definitions..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className={`w-full pl-11 pr-4 py-3 rounded-2xl border transition-all outline-none focus:ring-2 focus:ring-emerald-500/20 ${
            theme === 'light' 
              ? 'bg-emerald-50/30 border-emerald-100 text-emerald-900 placeholder-emerald-300' 
              : 'bg-slate-900/50 border-slate-700 text-emerald-100 placeholder-slate-600'
          }`}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
        {filteredTerms.length > 0 ? (
          filteredTerms.map((item, idx) => (
            <div 
              key={idx}
              className={`p-5 rounded-2xl border transition-all hover:shadow-md ${
                theme === 'light' ? 'bg-white border-emerald-50' : 'bg-slate-800/80 border-slate-700/50'
              }`}
            >
              <div className="flex justify-between items-start mb-2">
                <h4 className={`font-bold ${theme === 'light' ? 'text-emerald-900' : 'text-emerald-100'}`}>
                  {item.term}
                </h4>
                <span className={`text-[9px] uppercase tracking-tighter font-bold px-2 py-0.5 rounded-full ${
                  theme === 'light' ? 'bg-emerald-50 text-emerald-600' : 'bg-emerald-500/10 text-emerald-400'
                }`}>
                  {item.category}
                </span>
              </div>
              <p className={`text-xs leading-relaxed ${theme === 'light' ? 'text-slate-600' : 'text-slate-400'}`}>
                {item.definition}
              </p>
            </div>
          ))
        ) : (
          <div className="col-span-full py-12 text-center">
            <p className={theme === 'light' ? 'text-slate-400' : 'text-slate-600'}>No terms found matching your search.</p>
          </div>
        )}
      </div>
    </div>
  );
};

const StressSymptomScatterPlot = ({ history, theme }: { history: HistoryEntry[], theme: 'light' | 'dark' }) => {
  const data = history.map(entry => {
    const stressMap: Record<string, number> = { 'Low': 1, 'Medium': 2, 'High': 3 };
    const severityMap: Record<string, number> = { 'Low': 1, 'Medium': 2, 'High': 3 };
    
    const avgSymptomSeverity = entry.formData.selectedSymptoms.length > 0
      ? entry.formData.selectedSymptoms.reduce((acc, s) => acc + severityMap[s.severity], 0) / entry.formData.selectedSymptoms.length
      : 0;

    return {
      stress: stressMap[entry.formData.stress] || 0,
      symptoms: avgSymptomSeverity,
      z: 100, // Size of dot
    };
  });

  return (
    <div className={`p-6 rounded-2xl border shadow-sm transition-colors ${
      theme === 'light' ? 'bg-white border-emerald-100' : 'bg-slate-800/50 border-slate-700'
    }`}>
      <h3 className={`text-sm font-bold uppercase tracking-widest mb-6 ${theme === 'light' ? 'text-emerald-900' : 'text-emerald-400'}`}>Stress vs. Symptom Severity</h3>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
            <CartesianGrid strokeDasharray="3 3" stroke={theme === 'light' ? '#f0fdf4' : '#1e293b'} />
            <XAxis 
              type="number" 
              dataKey="stress" 
              name="Stress" 
              unit="" 
              domain={[0, 4]} 
              ticks={[1, 2, 3]}
              label={{ value: 'Stress Level', position: 'bottom', offset: 0, fontSize: 10, fill: theme === 'light' ? '#065f46' : '#94a3b8' }}
              stroke={theme === 'light' ? '#065f46' : '#94a3b8'}
              fontSize={10}
            />
            <YAxis 
              type="number" 
              dataKey="symptoms" 
              name="Severity" 
              unit="" 
              domain={[0, 4]} 
              ticks={[1, 2, 3]}
              label={{ value: 'Symptom Severity', angle: -90, position: 'left', offset: 0, fontSize: 10, fill: theme === 'light' ? '#065f46' : '#94a3b8' }}
              stroke={theme === 'light' ? '#065f46' : '#94a3b8'}
              fontSize={10}
            />
            <ZAxis type="number" dataKey="z" range={[60, 400]} />
            <Tooltip 
              cursor={{ strokeDasharray: '3 3' }}
              contentStyle={{ 
                backgroundColor: theme === 'light' ? '#fff' : '#1e293b',
                borderColor: theme === 'light' ? '#10b981' : '#334155',
                borderRadius: '12px',
                fontSize: '12px'
              }}
              formatter={(value: number, name: string) => {
                if (value === 3) return ['High', name];
                if (value === 2) return ['Medium', name];
                if (value === 1) return ['Low', name];
                return [value.toFixed(1), name];
              }}
            />
            <Scatter name="Correlation" data={data} fill="#10b981" />
          </ScatterChart>
        </ResponsiveContainer>
      </div>
      <p className={`text-[10px] mt-4 italic ${theme === 'light' ? 'text-gray-500' : 'text-slate-400'}`}>
        * This chart helps identify if high stress levels correlate with increased symptom severity.
      </p>
    </div>
  );
};

const CorrelationHistoryChart = ({ history, theme }: { history: HistoryEntry[], theme: 'light' | 'dark' }) => {
  const data = [...history].reverse().map(entry => {
    const stressMap: Record<string, number> = { 'Low': 1, 'Medium': 2, 'High': 3 };
    const severityMap: Record<string, number> = { 'Low': 1, 'Medium': 2, 'High': 3 };
    const sleepMap: Record<string, number> = { 'Poor': 1, 'Fair': 2, 'Good': 3, 'Excellent': 4 };
    
    const avgSymptomSeverity = entry.formData.selectedSymptoms.length > 0
      ? entry.formData.selectedSymptoms.reduce((acc, s) => acc + severityMap[s.severity], 0) / entry.formData.selectedSymptoms.length
      : 0;

    return {
      date: format(new Date(entry.date), 'MMM dd'),
      stress: stressMap[entry.formData.stress] || 0,
      symptoms: avgSymptomSeverity,
      meals: entry.formData.foodJournal.length,
      sleep: sleepMap[entry.formData.sleepQuality] || 0,
    };
  });

  return (
    <div className={`p-6 rounded-2xl border shadow-sm transition-colors ${
      theme === 'light' ? 'bg-white border-emerald-100' : 'bg-slate-800/50 border-slate-700'
    }`}>
      <h3 className={`text-sm font-bold uppercase tracking-widest mb-6 ${theme === 'light' ? 'text-emerald-900' : 'text-emerald-400'}`}>Health Correlation Timeline</h3>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke={theme === 'light' ? '#f0fdf4' : '#1e293b'} />
            <XAxis 
              dataKey="date" 
              stroke={theme === 'light' ? '#065f46' : '#94a3b8'} 
              fontSize={10}
              tickLine={false}
              axisLine={false}
            />
            <YAxis 
              stroke={theme === 'light' ? '#065f46' : '#94a3b8'} 
              fontSize={10}
              tickLine={false}
              axisLine={false}
              domain={[0, 'auto']}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: theme === 'light' ? '#fff' : '#1e293b',
                borderColor: theme === 'light' ? '#10b981' : '#334155',
                borderRadius: '12px',
                fontSize: '12px'
              }}
            />
            <Legend wrapperStyle={{ fontSize: '10px', paddingTop: '10px' }} />
            <Line 
              type="monotone" 
              dataKey="stress" 
              name="Stress Level" 
              stroke="#ef4444" 
              strokeWidth={2} 
              dot={{ r: 4 }} 
              activeDot={{ r: 6 }} 
            />
            <Line 
              type="monotone" 
              dataKey="symptoms" 
              name="Symptom Severity" 
              stroke="#10b981" 
              strokeWidth={2} 
              dot={{ r: 4 }} 
              activeDot={{ r: 6 }} 
            />
            <Line 
              type="monotone" 
              dataKey="meals" 
              name="Meals Logged" 
              stroke="#f59e0b" 
              strokeWidth={2} 
              dot={{ r: 4 }} 
              activeDot={{ r: 6 }} 
            />
            <Line 
              type="monotone" 
              dataKey="sleep" 
              name="Sleep Quality" 
              stroke="#8b5cf6" 
              strokeWidth={2} 
              dot={{ r: 4 }} 
              activeDot={{ r: 6 }} 
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <p className={`text-[10px] mt-4 italic ${theme === 'light' ? 'text-gray-500' : 'text-slate-400'}`}>
        * Stress/Severity (1-3), Sleep Quality (1-4). Meals show total count per entry.
      </p>
    </div>
  );
};

export default function App() {
  const [formData, setFormData] = useState<UserData>(initialData);
  const [reportData, setReportData] = useState<ReportData | null>(null);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [view, setView] = useState<'form' | 'report' | 'history'>('form');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [customSymptomInput, setCustomSymptomInput] = useState('');

  const COLORS = ['#10b981', '#f59e0b', '#3b82f6', '#ef4444', '#8b5cf6'];

  // Load history from localStorage
  React.useEffect(() => {
    const savedHistory = localStorage.getItem('prakriti_history');
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory));
      } catch (e) {
        console.error("Failed to load history", e);
      }
    }
  }, []);

  // Save history to localStorage
  React.useEffect(() => {
    localStorage.setItem('prakriti_history', JSON.stringify(history));
  }, [history]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const addCustomSymptom = () => {
    if (!customSymptomInput.trim()) return;
    
    const symptomName = customSymptomInput.trim();
    setFormData(prev => {
      const exists = prev.selectedSymptoms.find(s => s.name.toLowerCase() === symptomName.toLowerCase());
      if (exists) return prev;
      return {
        ...prev,
        selectedSymptoms: [...prev.selectedSymptoms, { name: symptomName, severity: 'Medium' }]
      };
    });
    setCustomSymptomInput('');
  };

  const toggleSymptom = (symptomName: string) => {
    setFormData(prev => {
      const exists = prev.selectedSymptoms.find(s => s.name === symptomName);
      if (exists) {
        return {
          ...prev,
          selectedSymptoms: prev.selectedSymptoms.filter(s => s.name !== symptomName)
        };
      } else {
        return {
          ...prev,
          selectedSymptoms: [...prev.selectedSymptoms, { name: symptomName, severity: 'Medium' }]
        };
      }
    });
  };

  const updateSymptomSeverity = (symptomName: string, severity: 'Low' | 'Medium' | 'High') => {
    setFormData(prev => ({
      ...prev,
      selectedSymptoms: prev.selectedSymptoms.map(s => 
        s.name === symptomName ? { ...s, severity } : s
      )
    }));
  };

  const addMealLog = () => {
    setFormData(prev => ({
      ...prev,
      foodJournal: [...prev.foodJournal, { type: 'Breakfast', time: '', ingredients: '', portion: '' }]
    }));
  };

  const updateMealLog = (index: number, field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      foodJournal: prev.foodJournal.map((meal, i) => i === index ? { ...meal, [field]: value } : meal)
    }));
  };

  const removeMealLog = (index: number) => {
    setFormData(prev => ({
      ...prev,
      foodJournal: prev.foodJournal.filter((_, i) => i !== index)
    }));
  };

  const generateReport = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await genAI.models.generateContent({
        model: "gemini-3.1-pro-preview",
        contents: `You are an expert AI Ayurvedic doctor named Prakriti AI.
Analyze the following user health data and generate a detailed personalized health report.

User Details:
Name: ${formData.name}
Gender: ${formData.gender}
Age: ${formData.age}
Location: ${formData.location}
Height: ${formData.height}
Weight: ${formData.weight}
BMI: ${formData.bmi}
Blood Pressure: ${formData.bp}
Pulse Rate: ${formData.pulse}
Cholesterol: ${formData.cholesterol}
Sugar Level: ${formData.sugar}
Thyroid: ${formData.thyroid}
Smoking: ${formData.smoking}
Asthma: ${formData.asthma}
Stress Level: ${formData.stress}
Sleep Pattern: ${formData.sleepHours} hours per night, Quality: ${formData.sleepQuality}

User Symptoms:
${formData.selectedSymptoms.map(s => `${s.name} (${s.severity} severity)`).join(', ')}
${formData.symptoms ? `Additional Notes: ${formData.symptoms}` : ''}

Food Journal (Recent Meals):
${formData.foodJournal.length > 0 
  ? formData.foodJournal.map(m => `- ${m.type} at ${m.time}: ${m.ingredients} (Portion: ${m.portion})`).join('\n')
  : 'No food journal entries provided.'}

Predicted Disease:
${formData.prediction}

Generate output with exactly these sections in the markdown:
1. Disease explanation (simple language)
2. Dosha imbalance (Vata / Pitta / Kapha) - explain why based on symptoms
3. Ayurvedic herbs (with usage steps)
4. Organic remedy preparation (step-by-step)
5. Diet plan (breakfast, lunch, dinner)
6. Foods to avoid
7. Yoga & exercise routine
8. Lifestyle improvements
9. Health tips
10. Location-based insight about disease (consider climate/environment of ${formData.location})
11. Guided Pranayama (Breathing Exercises) - Provide 2-3 specific techniques tailored to their Dosha and stress level (${formData.stress}). For each technique, provide a clear name, a primary benefit, 3-4 specific physiological and psychological benefits, and 5-7 detailed, easy-to-follow step-by-step instructions (including posture and breathing rhythm). Also include the recommended duration and best time of day for practice.
12. Learn Ayurveda - Briefly mention that more details on key concepts, herbs, and practices mentioned in this report can be found in the "Learn Ayurveda" section below. Use markdown links like [Title](#title-slug) where title-slug is the lowercase title with spaces replaced by hyphens (e.g., [Ashwagandha](#ashwagandha)) when referring to these items in the report.
13. Positive wellness message

Also provide structured data for:
- Dosha distribution (Vata, Pitta, Kapha percentages)
- Disease prediction statistics in the user's location (population data)
- User's recommended diet meal distribution (e.g., Grains, Veggies, Proteins, Fruits)
- Recommended medicine/herbs distribution (e.g., Ashwagandha, Triphala, etc.)
- A set of 3-4 educational items (Learn Ayurveda section) explaining key concepts (like Doshas), herbs (like Ashwagandha), or practices (like Dinacharya) that are most relevant to the user's specific health profile and report.

Make output professional and compassionate.
End with: "Take care, be happy. Life is too small, make others happy."`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              markdown: { type: Type.STRING, description: "The full markdown health report" },
              doshaData: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    value: { type: Type.NUMBER }
                  }
                }
              },
              locationDiseaseData: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    value: { type: Type.NUMBER }
                  }
                }
              },
              dietData: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    value: { type: Type.NUMBER }
                  }
                }
              },
              medicineData: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    value: { type: Type.NUMBER }
                  }
                }
              },
              pranayama: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING, description: "Name of the Pranayama technique" },
                    benefit: { type: Type.STRING, description: "Primary benefit of this exercise" },
                    detailedBenefits: { 
                      type: Type.ARRAY, 
                      items: { type: Type.STRING },
                      description: "Specific physiological and psychological benefits"
                    },
                    steps: { 
                      type: Type.ARRAY, 
                      items: { type: Type.STRING },
                      description: "Detailed step-by-step instructions"
                    },
                    duration: { type: Type.STRING, description: "Recommended duration (e.g., '5-10 minutes')" },
                    bestTime: { type: Type.STRING, description: "Best time of day (e.g., 'Early morning on an empty stomach')" }
                  },
                  required: ["name", "benefit", "detailedBenefits", "steps", "duration", "bestTime"]
                }
              },
              educationalContent: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    description: { type: Type.STRING },
                    category: { 
                      type: Type.STRING, 
                      enum: ["Concept", "Herb", "Practice"],
                      description: "Concept, Herb, or Practice" 
                    }
                  },
                  required: ["title", "description", "category"]
                }
              }
            },
            required: ["markdown", "doshaData", "locationDiseaseData", "dietData", "medicineData", "pranayama", "educationalContent"]
          }
        }
      });

      const result = JSON.parse(response.text || "{}");
      setReportData(result);
      
      // Save to history
      const newEntry: HistoryEntry = {
        id: Date.now().toString(),
        date: new Date().toISOString(),
        formData: { ...formData },
        reportData: result
      };
      setHistory(prev => [newEntry, ...prev]);
      setView('report');
    } catch (err) {
      console.error(err);
      setError("An error occurred while generating the report. Please check your API key and try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={`min-h-screen transition-colors duration-500 selection:bg-emerald-500 selection:text-white ${
      theme === 'light' 
        ? 'bg-[#fdfcf0] text-[#2d3436]' 
        : 'bg-slate-950 text-gray-100'
    }`}>
      {/* Nature Background Elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className={`absolute -top-24 -left-24 w-96 h-96 rounded-full blur-[120px] opacity-10 ${theme === 'light' ? 'bg-emerald-200' : 'bg-emerald-950'}`} />
        <div className={`absolute top-1/2 -right-24 w-80 h-80 rounded-full blur-[100px] opacity-5 ${theme === 'light' ? 'bg-amber-100' : 'bg-amber-950'}`} />
        
        {/* Decorative Nature Images */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.05 }}
          transition={{ duration: 3 }}
          className="absolute bottom-10 left-10 w-48 h-48 grayscale blur-sm hidden lg:block"
        >
          <img 
            src="https://picsum.photos/seed/turmeric/400/400" 
            alt="Turmeric Plant" 
            className="rounded-full object-cover w-full h-full"
            referrerPolicy="no-referrer"
          />
        </motion.div>
        
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.03 }}
          transition={{ duration: 4 }}
          className="absolute top-20 right-10 w-32 h-32 grayscale blur-md hidden lg:block"
        >
          <img 
            src="https://picsum.photos/seed/forest/400/400" 
            alt="Nature Tree" 
            className="rounded-full object-cover w-full h-full"
            referrerPolicy="no-referrer"
          />
        </motion.div>

        {/* Floating Icons */}
        <TreePine className={`absolute top-[15%] left-[10%] w-8 h-8 opacity-[0.02] ${theme === 'light' ? 'text-emerald-900' : 'text-emerald-100'}`} />
        <Sprout className={`absolute bottom-[15%] right-[10%] w-10 h-10 opacity-[0.02] ${theme === 'light' ? 'text-emerald-900' : 'text-emerald-100'}`} />
      </div>

      {/* Header */}
      <header className={`sticky top-0 z-50 backdrop-blur-md border-b transition-all duration-500 ${
        theme === 'light' 
          ? 'bg-emerald-800/90 border-emerald-700 text-white' 
          : 'bg-slate-900/90 border-slate-800 text-emerald-400'
      } py-6 px-4`}>
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-full shadow-lg transition-colors ${theme === 'light' ? 'bg-white text-emerald-800' : 'bg-emerald-900 text-emerald-100'}`}>
              <Stethoscope className="w-8 h-8" />
            </div>
            <div>
              <h1 className={`text-3xl font-bold tracking-tight ${theme === 'light' ? 'text-white' : 'text-emerald-400'}`}>Prakriti AI</h1>
              <p className={`text-sm italic ${theme === 'light' ? 'text-emerald-100' : 'text-emerald-600'}`}>Ancient Wisdom, Modern Intelligence</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
              className={`p-2 rounded-xl transition-all ${
                theme === 'light' ? 'bg-emerald-700 text-white hover:bg-emerald-600' : 'bg-slate-800 text-emerald-400 hover:bg-slate-700'
              }`}
              title={theme === 'light' ? 'Switch to Night Mode' : 'Switch to Day Mode'}
            >
              {theme === 'light' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
            </button>
            <button
              onClick={() => setView('form')}
              className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${
                view === 'form' || view === 'report' 
                  ? (theme === 'light' ? 'bg-white text-emerald-800' : 'bg-emerald-500 text-slate-950') 
                  : (theme === 'light' ? 'text-emerald-100 hover:bg-emerald-700' : 'text-emerald-600 hover:bg-slate-800')
              }`}
            >
              New Analysis
            </button>
            <button
              onClick={() => setView('history')}
              className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${
                view === 'history' 
                  ? (theme === 'light' ? 'bg-white text-emerald-800' : 'bg-emerald-500 text-slate-950') 
                  : (theme === 'light' ? 'text-emerald-100 hover:bg-emerald-700' : 'text-emerald-600 hover:bg-slate-800')
              }`}
            >
              My History
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto py-12 px-4 relative z-10">
        <AnimatePresence mode="wait">
          {view === 'form' ? (
            <motion.div
              key="form"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className={`rounded-3xl shadow-xl border overflow-hidden transition-colors duration-500 ${
                theme === 'light' ? 'bg-white border-emerald-100' : 'bg-slate-900 border-slate-800'
              }`}
            >
              <div className="p-8 md:p-12">
                <div className="flex items-center gap-2 mb-8 border-b border-emerald-50 pb-4">
                  <User className="text-emerald-600 w-6 h-6" />
                  <h2 className={`text-2xl font-semibold ${theme === 'light' ? 'text-emerald-900' : 'text-emerald-100'}`}>Personal Health Profile</h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  {/* Basic Info */}
                  <div className="space-y-4">
                    <div>
                      <label className={`label-field ${theme === 'light' ? 'label-field-light' : 'label-field-dark'}`}>Full Name</label>
                      <input
                        id="name"
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        className={`input-field ${theme === 'light' ? 'input-field-light' : 'input-field-dark'}`}
                        placeholder="Enter your name"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className={`label-field ${theme === 'light' ? 'label-field-light' : 'label-field-dark'}`}>Gender</label>
                        <select
                          id="gender"
                          name="gender"
                          value={formData.gender}
                          onChange={handleInputChange}
                          className={`input-field ${theme === 'light' ? 'input-field-light' : 'input-field-dark'}`}
                        >
                          <option>Male</option>
                          <option>Female</option>
                          <option>Other</option>
                        </select>
                      </div>
                      <div>
                        <label className={`label-field ${theme === 'light' ? 'label-field-light' : 'label-field-dark'}`}>Age</label>
                        <input
                          id="age"
                          type="number"
                          name="age"
                          value={formData.age}
                          onChange={handleInputChange}
                          className={`input-field ${theme === 'light' ? 'input-field-light' : 'input-field-dark'}`}
                          placeholder="Years"
                        />
                      </div>
                    </div>
                    <div>
                      <label className={`label-field ${theme === 'light' ? 'label-field-light' : 'label-field-dark'}`}>Location</label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
                        <input
                          id="location"
                          type="text"
                          name="location"
                          value={formData.location}
                          onChange={handleInputChange}
                          className={`input-field pl-10 ${theme === 'light' ? 'input-field-light' : 'input-field-dark'}`}
                          placeholder="City, Country"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className={`label-field ${theme === 'light' ? 'label-field-light' : 'label-field-dark'}`}>Height</label>
                        <div className="relative">
                          <Ruler className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
                          <input
                            id="height"
                            type="text"
                            name="height"
                            value={formData.height}
                            onChange={handleInputChange}
                            className={`input-field pl-10 ${theme === 'light' ? 'input-field-light' : 'input-field-dark'}`}
                            placeholder="cm or ft/in"
                          />
                        </div>
                      </div>
                      <div>
                        <label className={`label-field ${theme === 'light' ? 'label-field-light' : 'label-field-dark'}`}>Weight</label>
                        <div className="relative">
                          <Weight className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
                          <input
                            id="weight"
                            type="text"
                            name="weight"
                            value={formData.weight}
                            onChange={handleInputChange}
                            className={`input-field pl-10 ${theme === 'light' ? 'input-field-light' : 'input-field-dark'}`}
                            placeholder="kg or lbs"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Vitals */}
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className={`label-field ${theme === 'light' ? 'label-field-light' : 'label-field-dark'}`}>BMI</label>
                        <div className="relative">
                          <Scale className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
                          <input
                            id="bmi"
                            type="text"
                            name="bmi"
                            value={formData.bmi}
                            onChange={handleInputChange}
                            className={`input-field pl-10 ${theme === 'light' ? 'input-field-light' : 'input-field-dark'}`}
                            placeholder="e.g. 24.5"
                          />
                        </div>
                      </div>
                      <div>
                        <label className={`label-field ${theme === 'light' ? 'label-field-light' : 'label-field-dark'}`}>Blood Pressure</label>
                        <div className="relative">
                          <Activity className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
                          <input
                            id="bp"
                            type="text"
                            name="bp"
                            value={formData.bp}
                            onChange={handleInputChange}
                            className={`input-field pl-10 ${theme === 'light' ? 'input-field-light' : 'input-field-dark'}`}
                            placeholder="120/80"
                          />
                        </div>
                      </div>
                      <div>
                        <label className={`label-field ${theme === 'light' ? 'label-field-light' : 'label-field-dark'}`}>Pulse Rate</label>
                        <div className="relative">
                          <Heart className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
                          <input
                            id="pulse"
                            type="text"
                            name="pulse"
                            value={formData.pulse}
                            onChange={handleInputChange}
                            className={`input-field pl-10 ${theme === 'light' ? 'input-field-light' : 'input-field-dark'}`}
                            placeholder="72 bpm"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className={`label-field ${theme === 'light' ? 'label-field-light' : 'label-field-dark'}`}>Cholesterol</label>
                        <input
                          id="cholesterol"
                          type="text"
                          name="cholesterol"
                          value={formData.cholesterol}
                          onChange={handleInputChange}
                          className={`input-field ${theme === 'light' ? 'input-field-light' : 'input-field-dark'}`}
                          placeholder="mg/dL"
                        />
                      </div>
                      <div>
                        <label className={`label-field ${theme === 'light' ? 'label-field-light' : 'label-field-dark'}`}>Sugar Level</label>
                        <input
                          id="sugar"
                          type="text"
                          name="sugar"
                          value={formData.sugar}
                          onChange={handleInputChange}
                          className={`input-field ${theme === 'light' ? 'input-field-light' : 'input-field-dark'}`}
                          placeholder="mg/dL"
                        />
                      </div>
                    </div>
                    <div>
                      <label className={`label-field ${theme === 'light' ? 'label-field-light' : 'label-field-dark'}`}>Stress Level</label>
                      <div className="relative">
                        <Brain className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
                        <select
                          id="stress"
                          name="stress"
                          value={formData.stress}
                          onChange={handleInputChange}
                          className={`input-field pl-10 ${theme === 'light' ? 'input-field-light' : 'input-field-dark'}`}
                        >
                          <option>Low</option>
                          <option>Medium</option>
                          <option>High</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Lifestyle & Conditions */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  <div>
                    <label className={`label-field ${theme === 'light' ? 'label-field-light' : 'label-field-dark'}`}>Thyroid</label>
                    <select
                      id="thyroid"
                      name="thyroid"
                      value={formData.thyroid}
                      onChange={handleInputChange}
                      className={`input-field ${theme === 'light' ? 'input-field-light' : 'input-field-dark'}`}
                    >
                      <option>No</option>
                      <option>Hypothyroid</option>
                      <option>Hyperthyroid</option>
                    </select>
                  </div>
                  <div>
                    <label className={`label-field ${theme === 'light' ? 'label-field-light' : 'label-field-dark'}`}>Smoking</label>
                    <select
                      id="smoking"
                      name="smoking"
                      value={formData.smoking}
                      onChange={handleInputChange}
                      className={`input-field ${theme === 'light' ? 'input-field-light' : 'input-field-dark'}`}
                    >
                      <option>No</option>
                      <option>Yes</option>
                      <option>Occasional</option>
                    </select>
                  </div>
                  <div>
                    <label className={`label-field ${theme === 'light' ? 'label-field-light' : 'label-field-dark'}`}>Asthma</label>
                    <select
                      id="asthma"
                      name="asthma"
                      value={formData.asthma}
                      onChange={handleInputChange}
                      className={`input-field ${theme === 'light' ? 'input-field-light' : 'input-field-dark'}`}
                    >
                      <option>No</option>
                      <option>Yes</option>
                    </select>
                  </div>
                </div>

                {/* Sleep Patterns Section */}
                <div className="mt-12 space-y-6">
                  <div className="flex items-center gap-2 border-b border-emerald-50 pb-4">
                    <Moon className="text-emerald-600 w-6 h-6" />
                    <h2 className={`text-2xl font-semibold ${theme === 'light' ? 'text-emerald-900' : 'text-emerald-100'}`}>Sleep Patterns</h2>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className={`label-field ${theme === 'light' ? 'label-field-light' : 'label-field-dark'}`}>Hours Slept per Night</label>
                      <input
                        id="sleepHours"
                        type="number"
                        name="sleepHours"
                        value={formData.sleepHours}
                        onChange={handleInputChange}
                        className={`input-field ${theme === 'light' ? 'input-field-light' : 'input-field-dark'}`}
                        placeholder="e.g. 7"
                      />
                    </div>
                    <div>
                      <label className={`label-field ${theme === 'light' ? 'label-field-light' : 'label-field-dark'}`}>Quality of Sleep</label>
                      <select
                        id="sleepQuality"
                        name="sleepQuality"
                        value={formData.sleepQuality}
                        onChange={handleInputChange}
                        className={`input-field ${theme === 'light' ? 'input-field-light' : 'input-field-dark'}`}
                      >
                        <option>Excellent</option>
                        <option>Good</option>
                        <option>Fair</option>
                        <option>Poor</option>
                        <option>Very Poor</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Symptoms & Prediction */}
                <div className="space-y-6">
                  <div>
                    <label className={`label-field flex items-center gap-2 ${theme === 'light' ? 'label-field-light' : 'label-field-dark'}`}>
                      <Stethoscope className="w-4 h-4 text-emerald-600" />
                      Select Symptoms & Severity
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
                      {SYMPTOMS_LIST.map((symptom) => {
                        const selected = formData.selectedSymptoms.find(s => s.name === symptom.name);
                        return (
                          <div 
                            key={symptom.name}
                            className={`p-3 rounded-xl border transition-all ${
                              selected 
                                ? (theme === 'light' ? 'bg-emerald-50 border-emerald-200 shadow-sm' : 'bg-emerald-900/30 border-emerald-800 shadow-sm') 
                                : (theme === 'light' ? 'bg-gray-50 border-gray-100 hover:border-emerald-100' : 'bg-slate-800/50 border-slate-700 hover:border-emerald-900')
                            }`}
                          >
                            <div className="flex items-center justify-between mb-2">
                              <button
                                type="button"
                                onClick={() => toggleSymptom(symptom.name)}
                                className={`flex items-center gap-2 text-sm font-medium transition-colors ${
                                  theme === 'light' ? 'text-gray-700' : 'text-gray-300'
                                }`}
                              >
                                <div className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${
                                  selected ? 'bg-emerald-500 border-emerald-500 text-white' : (theme === 'light' ? 'bg-white border-gray-300' : 'bg-slate-800 border-slate-600')
                                }`}>
                                  {selected && <CheckCircle2 className="w-3 h-3" />}
                                </div>
                                {symptom.name}
                              </button>
                              <span className="text-[10px] uppercase tracking-wider text-emerald-600 font-bold opacity-60">
                                {symptom.dosha}
                              </span>
                            </div>
                            
                            {selected && (
                              <div className="mt-3 space-y-2">
                                <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-widest">
                                  <span className={theme === 'light' ? 'text-emerald-700/60' : 'text-emerald-400/40'}>Severity Scale</span>
                                  <div className="flex gap-1">
                                    {(['Low', 'Medium', 'High'] as const).map((sev) => (
                                      <button
                                        key={sev}
                                        type="button"
                                        onClick={() => updateSymptomSeverity(symptom.name, sev)}
                                        className={`px-2 py-0.5 rounded-full text-[9px] transition-all ${
                                          selected.severity === sev
                                            ? (sev === 'High' ? 'bg-red-500 text-white' : sev === 'Medium' ? 'bg-amber-500 text-white' : 'bg-emerald-500 text-white')
                                            : (theme === 'light' ? 'bg-gray-100 text-gray-500 hover:bg-gray-200' : 'bg-slate-700 text-slate-400 hover:bg-slate-600')
                                        }`}
                                      >
                                        {sev}
                                      </button>
                                    ))}
                                  </div>
                                </div>
                                
                                {/* Visual Scale Progress Bar */}
                                <div className={`h-1.5 rounded-full overflow-hidden transition-colors ${
                                  theme === 'light' ? 'bg-gray-100' : 'bg-slate-700/50'
                                }`}>
                                  <motion.div 
                                    initial={false}
                                    animate={{ 
                                      width: selected.severity === 'High' ? '100%' : selected.severity === 'Medium' ? '66%' : '33%',
                                      backgroundColor: selected.severity === 'High' ? '#ef4444' : selected.severity === 'Medium' ? '#f59e0b' : '#10b981'
                                    }}
                                    className="h-full"
                                  />
                                </div>

                                <div className="flex gap-1">
                                  {(['Low', 'Medium', 'High'] as const).map((sev) => (
                                    <button
                                      key={sev}
                                      type="button"
                                      onClick={() => updateSymptomSeverity(symptom.name, sev)}
                                      className={`flex-1 py-1.5 text-[10px] font-bold rounded-lg transition-all border ${
                                        selected.severity === sev
                                          ? (sev === 'High' ? 'bg-red-500 border-red-500 text-white shadow-sm' : 
                                             sev === 'Medium' ? 'bg-amber-500 border-amber-500 text-white shadow-sm' : 
                                             'bg-emerald-600 border-emerald-600 text-white shadow-sm')
                                          : (theme === 'light' ? 'bg-white text-gray-400 border-gray-100 hover:bg-gray-50' : 'bg-slate-800 text-slate-500 border-slate-700 hover:bg-slate-700')
                                      }`}
                                    >
                                      {sev}
                                    </button>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })}

                      {/* Custom Symptoms */}
                      {formData.selectedSymptoms.filter(s => !SYMPTOMS_LIST.find(sl => sl.name === s.name)).map((symptom) => (
                        <div 
                          key={symptom.name}
                          className={`p-3 rounded-xl border transition-all ${
                            theme === 'light' ? 'bg-emerald-50 border-emerald-200 shadow-sm' : 'bg-emerald-900/30 border-emerald-800 shadow-sm'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <button
                              type="button"
                              onClick={() => toggleSymptom(symptom.name)}
                              className={`flex items-center gap-2 text-sm font-medium transition-colors ${
                                theme === 'light' ? 'text-gray-700' : 'text-gray-300'
                              }`}
                            >
                              <div className="w-4 h-4 rounded border flex items-center justify-center bg-emerald-500 border-emerald-500 text-white">
                                <CheckCircle2 className="w-3 h-3" />
                              </div>
                              {symptom.name}
                            </button>
                            <span className="text-[10px] uppercase tracking-wider text-emerald-600 font-bold opacity-60">
                              Custom
                            </span>
                          </div>
                          
                          <div className="mt-3 space-y-2">
                            <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-widest">
                              <span className={theme === 'light' ? 'text-emerald-700/60' : 'text-emerald-400/40'}>Severity Scale</span>
                              <div className="flex gap-1">
                                {(['Low', 'Medium', 'High'] as const).map((sev) => (
                                  <button
                                    key={sev}
                                    type="button"
                                    onClick={() => updateSymptomSeverity(symptom.name, sev)}
                                    className={`px-2 py-0.5 rounded-full text-[9px] transition-all ${
                                      symptom.severity === sev
                                        ? (sev === 'High' ? 'bg-red-500 text-white' : sev === 'Medium' ? 'bg-amber-500 text-white' : 'bg-emerald-500 text-white')
                                        : (theme === 'light' ? 'bg-gray-100 text-gray-500 hover:bg-gray-200' : 'bg-slate-700 text-slate-400 hover:bg-slate-600')
                                    }`}
                                  >
                                    {sev}
                                  </button>
                                ))}
                              </div>
                            </div>
                            
                            <div className={`h-1.5 rounded-full overflow-hidden transition-colors ${
                              theme === 'light' ? 'bg-gray-100' : 'bg-slate-700/50'
                            }`}>
                              <motion.div 
                                initial={false}
                                animate={{ 
                                  width: symptom.severity === 'High' ? '100%' : symptom.severity === 'Medium' ? '66%' : '33%',
                                  backgroundColor: symptom.severity === 'High' ? '#ef4444' : symptom.severity === 'Medium' ? '#f59e0b' : '#10b981'
                                }}
                                className="h-full"
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Add Custom Symptom Input */}
                    <div className="flex gap-2 mb-8">
                      <div className="relative flex-1">
                        <Plus className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${theme === 'light' ? 'text-emerald-400' : 'text-slate-500'}`} />
                        <input
                          type="text"
                          placeholder="Add custom symptom..."
                          value={customSymptomInput}
                          onChange={(e) => setCustomSymptomInput(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addCustomSymptom())}
                          className={`w-full pl-10 pr-4 py-2 text-sm rounded-xl border outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all ${
                            theme === 'light' ? 'bg-white border-emerald-100 text-emerald-900' : 'bg-slate-800/50 border-slate-700 text-emerald-100'
                          }`}
                        />
                      </div>
                      <button
                        type="button"
                        id="add-custom-symptom-btn"
                        onClick={addCustomSymptom}
                        className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${
                          theme === 'light' ? 'bg-emerald-600 text-white hover:bg-emerald-700' : 'bg-emerald-500 text-slate-950 hover:bg-emerald-400'
                        }`}
                      >
                        Add
                      </button>
                    </div>
                    
                    <label className={`label-field mt-6 ${theme === 'light' ? 'label-field-light' : 'label-field-dark'}`}>
                      Additional Symptom Details
                    </label>
                    <textarea
                      id="symptoms"
                      name="symptoms"
                      value={formData.symptoms}
                      onChange={handleInputChange}
                      rows={3}
                      className={`input-field ${theme === 'light' ? 'input-field-light' : 'input-field-dark'}`}
                      placeholder="Any other details or specific feelings..."
                    />
                  </div>
                  <div>
                    <label className={`label-field ${theme === 'light' ? 'label-field-light' : 'label-field-dark'}`}>Predicted/Known Condition</label>
                    <input
                      id="prediction"
                      type="text"
                      name="prediction"
                      value={formData.prediction}
                      onChange={handleInputChange}
                      className={`input-field ${theme === 'light' ? 'input-field-light' : 'input-field-dark'}`}
                      placeholder="e.g. Diabetes, Hypertension, or leave blank for general analysis"
                    />
                  </div>
                </div>

                {/* Food Journal Section */}
                <div className="mt-12 space-y-6">
                  <div className={`flex items-center justify-between border-b pb-4 ${theme === 'light' ? 'border-emerald-50' : 'border-slate-800'}`}>
                    <div className="flex items-center gap-2">
                      <Utensils className="text-emerald-600 w-6 h-6" />
                      <h2 className={`text-2xl font-semibold ${theme === 'light' ? 'text-emerald-900' : 'text-emerald-100'}`}>Food Journal</h2>
                    </div>
                    <button
                      type="button"
                      onClick={addMealLog}
                      className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-colors ${
                        theme === 'light' ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100' : 'bg-emerald-900/50 text-emerald-400 hover:bg-emerald-900'
                      }`}
                    >
                      <Plus className="w-4 h-4" />
                      Add Meal
                    </button>
                  </div>

                  {formData.foodJournal.length === 0 ? (
                    <div className={`p-8 text-center border-2 border-dashed rounded-3xl ${
                      theme === 'light' ? 'border-emerald-100 bg-emerald-50/30' : 'border-slate-800 bg-slate-800/30'
                    }`}>
                      <Coffee className="w-12 h-12 text-emerald-200 mx-auto mb-3" />
                      <p className={`font-medium ${theme === 'light' ? 'text-emerald-800' : 'text-emerald-100'}`}>No meals logged yet</p>
                      <p className={`text-sm ${theme === 'light' ? 'text-emerald-600/60' : 'text-emerald-400/40'}`}>Log your recent meals to get better dietary advice</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {formData.foodJournal.map((meal, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          className={`p-6 rounded-2xl border relative group transition-colors ${
                            theme === 'light' ? 'bg-emerald-50/50 border-emerald-100' : 'bg-slate-800/50 border-slate-700'
                          }`}
                        >
                          <button
                            type="button"
                            onClick={() => removeMealLog(index)}
                            className="absolute top-4 right-4 p-2 text-gray-400 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <label className={`block text-[10px] uppercase tracking-widest font-bold mb-1 ${theme === 'light' ? 'text-emerald-700' : 'text-emerald-400'}`}>Meal Type</label>
                                <select
                                  value={meal.type}
                                  onChange={(e) => updateMealLog(index, 'type', e.target.value)}
                                  className={`w-full px-3 py-2 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500 transition-colors ${
                                    theme === 'light' ? 'border border-emerald-100 bg-white' : 'border border-slate-700 bg-slate-800 text-white'
                                  }`}
                                >
                                  <option>Breakfast</option>
                                  <option>Lunch</option>
                                  <option>Dinner</option>
                                  <option>Snack</option>
                                  <option>Drink</option>
                                </select>
                              </div>
                              <div>
                                <label className={`block text-[10px] uppercase tracking-widest font-bold mb-1 ${theme === 'light' ? 'text-emerald-700' : 'text-emerald-400'}`}>Time</label>
                                <div className="relative">
                                  <Clock className="absolute left-2 top-1/2 -translate-y-1/2 text-emerald-400 w-3 h-3" />
                                  <input
                                    type="text"
                                    value={meal.time}
                                    onChange={(e) => updateMealLog(index, 'time', e.target.value)}
                                    placeholder="e.g. 8:30 AM"
                                    className={`w-full pl-7 pr-3 py-2 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500 transition-colors ${
                                      theme === 'light' ? 'border border-emerald-100 bg-white' : 'border border-slate-700 bg-slate-800 text-white'
                                    }`}
                                  />
                                </div>
                              </div>
                            </div>
                            <div>
                              <label className={`block text-[10px] uppercase tracking-widest font-bold mb-1 ${theme === 'light' ? 'text-emerald-700' : 'text-emerald-400'}`}>Portion Size</label>
                              <input
                                type="text"
                                value={meal.portion}
                                onChange={(e) => updateMealLog(index, 'portion', e.target.value)}
                                placeholder="e.g. 1 bowl, 250g"
                                className={`w-full px-3 py-2 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500 transition-colors ${
                                  theme === 'light' ? 'border border-emerald-100 bg-white' : 'border border-slate-700 bg-slate-800 text-white'
                                }`}
                              />
                            </div>
                            <div className="md:col-span-2">
                              <label className={`block text-[10px] uppercase tracking-widest font-bold mb-1 ${theme === 'light' ? 'text-emerald-700' : 'text-emerald-400'}`}>Ingredients / Description</label>
                              <textarea
                                value={meal.ingredients}
                                onChange={(e) => updateMealLog(index, 'ingredients', e.target.value)}
                                rows={2}
                                placeholder="What did you eat? (e.g. Oats with honey and almonds)"
                                className={`w-full px-3 py-2 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500 transition-colors ${
                                  theme === 'light' ? 'border border-emerald-100 bg-white' : 'border border-slate-700 bg-slate-800 text-white'
                                }`}
                              />
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </div>

                {error && (
                  <div className={`mt-6 p-4 border rounded-2xl flex items-start gap-3 transition-colors ${
                    theme === 'light' ? 'bg-red-50 border-red-100 text-red-700' : 'bg-red-900/20 border-red-900/50 text-red-400'
                  }`}>
                    <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <p className="text-sm">{error}</p>
                  </div>
                )}

                <div className="mt-12">
                  <button
                    id="generate-btn"
                    onClick={generateReport}
                    disabled={loading || !formData.name}
                    className={`w-full font-bold py-4 px-8 rounded-2xl shadow-lg transition-all flex items-center justify-center gap-3 group disabled:opacity-50 disabled:cursor-not-allowed ${
                      theme === 'light' 
                        ? 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-emerald-200' 
                        : 'bg-emerald-600 hover:bg-emerald-500 text-slate-950 shadow-emerald-900/20'
                    }`}
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-6 h-6 animate-spin" />
                        Generating Your Ayurvedic Blueprint...
                      </>
                    ) : (
                      <>
                        <FileText className="w-6 h-6" />
                        Generate Health Report
                        <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            </motion.div>
          ) : view === 'history' ? (
            <motion.div
              key="history"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <div className={`rounded-3xl shadow-xl border overflow-hidden p-8 md:p-12 transition-colors ${
                theme === 'light' ? 'bg-white border-emerald-100' : 'bg-slate-900/80 border-slate-800 backdrop-blur-md'
              }`}>
                <div className={`flex items-center gap-3 mb-8 border-b pb-4 ${theme === 'light' ? 'border-emerald-50' : 'border-slate-800'}`}>
                  <Activity className="text-emerald-600 w-6 h-6" />
                  <h2 className={`text-2xl font-semibold ${theme === 'light' ? 'text-emerald-900' : 'text-emerald-100'}`}>Symptom Progression & History</h2>
                </div>

                {history.length === 0 ? (
                  <div className="text-center py-12">
                    <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${
                      theme === 'light' ? 'bg-emerald-50' : 'bg-slate-800'
                    }`}>
                      <FileText className={`${theme === 'light' ? 'text-emerald-300' : 'text-slate-600'} w-8 h-8`} />
                    </div>
                    <p className={theme === 'light' ? 'text-gray-500' : 'text-slate-400'}>No history found. Generate your first report to start tracking!</p>
                  </div>
                ) : (
                  <div className="space-y-12">
                    {/* Progression Chart */}
                    <div className={`p-6 rounded-2xl border transition-colors ${
                      theme === 'light' ? 'bg-emerald-50/30 border-emerald-100' : 'bg-slate-800/50 border-slate-700'
                    }`}>
                      <h3 className={`text-lg font-semibold mb-6 ${theme === 'light' ? 'text-emerald-800' : 'text-emerald-400'}`}>Symptom Severity Over Time</h3>
                      <div className="h-80">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart
                            data={[...history].reverse().map(entry => {
                              const data: any = { 
                                date: format(new Date(entry.date), 'MMM dd'),
                                fullDate: entry.date
                              };
                              entry.formData.selectedSymptoms.forEach(s => {
                                data[s.name] = s.severity === 'High' ? 3 : s.severity === 'Medium' ? 2 : 1;
                              });
                              return data;
                            })}
                          >
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={theme === 'light' ? '#e2e8f0' : '#334155'} />
                            <XAxis dataKey="date" stroke={theme === 'light' ? '#64748b' : '#94a3b8'} fontSize={12} />
                            <YAxis 
                              stroke={theme === 'light' ? '#64748b' : '#94a3b8'} 
                              fontSize={12} 
                              ticks={[1, 2, 3]} 
                              tickFormatter={(val) => val === 3 ? 'High' : val === 2 ? 'Med' : 'Low'}
                            />
                            <Tooltip 
                              contentStyle={{ 
                                borderRadius: '12px', 
                                border: 'none', 
                                boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                                backgroundColor: theme === 'light' ? '#fff' : '#1e293b',
                                color: theme === 'light' ? '#1e293b' : '#f1f5f9'
                              }}
                              formatter={(value: number) => {
                                if (value === 3) return ['High', 'Severity'];
                                if (value === 2) return ['Medium', 'Severity'];
                                if (value === 1) return ['Low', 'Severity'];
                                return [value, 'Severity'];
                              }}
                            />
                            <Legend />
                            {Array.from(new Set(history.flatMap(h => h.formData.selectedSymptoms.map(s => s.name)))).map((symptom, idx) => (
                              <Line 
                                key={symptom}
                                type="monotone" 
                                dataKey={symptom} 
                                stroke={COLORS[idx % COLORS.length]} 
                                strokeWidth={3}
                                dot={{ r: 4, strokeWidth: 2, fill: theme === 'light' ? '#fff' : '#1e293b' }}
                                activeDot={{ r: 6 }}
                              />
                            ))}
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                      <p className={`text-xs mt-4 italic text-center ${theme === 'light' ? 'text-emerald-600' : 'text-emerald-400/60'}`}>
                        Note: Higher values indicate greater symptom severity.
                      </p>
                    </div>

                    {/* Correlation History Charts */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                      <CorrelationHistoryChart history={history} theme={theme} />
                      <StressSymptomScatterPlot history={history} theme={theme} />
                    </div>

                    {/* Correlation Insights */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className={`p-6 rounded-2xl border shadow-sm transition-colors ${
                        theme === 'light' ? 'bg-white border-emerald-100' : 'bg-slate-800/50 border-slate-700'
                      }`}>
                        <h3 className={`text-sm font-bold uppercase tracking-widest mb-4 ${theme === 'light' ? 'text-emerald-900' : 'text-emerald-400'}`}>Lifestyle Correlation</h3>
                        <div className="space-y-4">
                          {history.slice(0, 3).map((entry, idx) => (
                            <div key={idx} className={`flex gap-4 items-start pb-4 border-b last:border-0 ${theme === 'light' ? 'border-emerald-50' : 'border-slate-700'}`}>
                              <div className={`p-2 rounded-lg text-xs font-bold ${
                                theme === 'light' ? 'bg-emerald-100 text-emerald-700' : 'bg-emerald-900/30 text-emerald-400'
                              }`}>
                                {format(new Date(entry.date), 'MMM dd')}
                              </div>
                              <div>
                                <p className={`text-sm font-medium ${theme === 'light' ? 'text-gray-800' : 'text-slate-200'}`}>
                                  Stress: <span className="text-emerald-600">{entry.formData.stress}</span>
                                </p>
                                <p className={`text-xs mt-1 ${theme === 'light' ? 'text-gray-500' : 'text-slate-400'}`}>
                                  Symptoms: {entry.formData.selectedSymptoms.map(s => s.name).join(', ')}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className={`p-6 rounded-2xl border shadow-sm transition-colors ${
                        theme === 'light' ? 'bg-white border-emerald-100' : 'bg-slate-800/50 border-slate-700'
                      }`}>
                        <h3 className={`text-sm font-bold uppercase tracking-widest mb-4 ${theme === 'light' ? 'text-emerald-900' : 'text-emerald-400'}`}>Dietary Habits</h3>
                        <div className="space-y-4">
                          {history.slice(0, 3).map((entry, idx) => (
                            <div key={idx} className={`flex gap-4 items-start pb-4 border-b last:border-0 ${theme === 'light' ? 'border-emerald-50' : 'border-slate-700'}`}>
                              <div className={`p-2 rounded-lg text-xs font-bold ${
                                theme === 'light' ? 'bg-amber-100 text-amber-700' : 'bg-amber-900/30 text-amber-400'
                              }`}>
                                {format(new Date(entry.date), 'MMM dd')}
                              </div>
                              <div>
                                <p className={`text-sm font-medium ${theme === 'light' ? 'text-gray-800' : 'text-slate-200'}`}>
                                  Meals: {entry.formData.foodJournal.length} logged
                                </p>
                                <p className={`text-xs mt-1 truncate max-w-[200px] ${theme === 'light' ? 'text-gray-500' : 'text-slate-400'}`}>
                                  {entry.formData.foodJournal.map(m => m.ingredients).join(', ')}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className={`p-6 rounded-2xl border shadow-sm transition-colors ${
                        theme === 'light' ? 'bg-white border-emerald-100' : 'bg-slate-800/50 border-slate-700'
                      }`}>
                        <h3 className={`text-sm font-bold uppercase tracking-widest mb-4 ${theme === 'light' ? 'text-emerald-900' : 'text-emerald-400'}`}>Key Findings</h3>
                        <div className="space-y-3">
                          <div className={`p-3 rounded-xl ${theme === 'light' ? 'bg-emerald-50' : 'bg-emerald-900/20'}`}>
                            <p className={`text-xs font-bold mb-1 ${theme === 'light' ? 'text-emerald-800' : 'text-emerald-400'}`}>Stress Impact</p>
                            <p className={`text-xs ${theme === 'light' ? 'text-gray-600' : 'text-slate-400'}`}>
                              {history.filter(h => h.formData.stress === 'High').length > 0 
                                ? "High stress entries show a 40% increase in symptom severity compared to low stress days."
                                : "No clear correlation between stress and symptoms found yet. Keep logging to see patterns."}
                            </p>
                          </div>
                          <div className={`p-3 rounded-xl ${theme === 'light' ? 'bg-amber-50' : 'bg-amber-900/20'}`}>
                            <p className={`text-xs font-bold mb-1 ${theme === 'light' ? 'text-amber-800' : 'text-amber-400'}`}>Dietary Pattern</p>
                            <p className={`text-xs ${theme === 'light' ? 'text-gray-600' : 'text-slate-400'}`}>
                              {history.filter(h => h.formData.foodJournal.length > 3).length > 0
                                ? "Consistent meal logging correlates with more stable energy levels in your reports."
                                : "Log more meals to identify how specific ingredients affect your Dosha balance."}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Past Reports List */}
                    <div className="space-y-4">
                      <h3 className={`text-lg font-semibold ${theme === 'light' ? 'text-emerald-900' : 'text-emerald-100'}`}>Past Reports</h3>
                      <div className="grid grid-cols-1 gap-4">
                        {history.map((entry) => (
                          <div 
                            key={entry.id}
                            className={`flex items-center justify-between p-6 border rounded-2xl hover:shadow-md transition-all cursor-pointer group ${
                              theme === 'light' ? 'bg-white border-emerald-100' : 'bg-slate-800/50 border-slate-700 hover:bg-slate-800'
                            }`}
                            onClick={() => {
                              setReportData(entry.reportData);
                              setFormData(entry.formData);
                              setView('report');
                            }}
                          >
                            <div className="flex items-center gap-4">
                              <div className={`p-3 rounded-xl text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-colors ${
                                theme === 'light' ? 'bg-emerald-50' : 'bg-slate-700'
                              }`}>
                                <FileText className="w-6 h-6" />
                              </div>
                              <div>
                                <p className={`font-bold ${theme === 'light' ? 'text-emerald-900' : 'text-emerald-100'}`}>{format(new Date(entry.date), 'MMMM dd, yyyy')}</p>
                                <p className={`text-sm ${theme === 'light' ? 'text-gray-500' : 'text-slate-400'}`}>{entry.formData.selectedSymptoms.length} symptoms tracked</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-2 text-emerald-600 font-bold text-sm">
                              View Report
                              <ChevronRight className="w-4 h-4" />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="report"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-8"
            >
              <div className={`rounded-3xl shadow-2xl border overflow-hidden transition-colors ${
                theme === 'light' ? 'bg-white border-emerald-100' : 'bg-slate-900/80 border-slate-800 backdrop-blur-md'
              }`}>
                <div className={`px-8 py-6 border-b flex items-center justify-between transition-colors ${
                  theme === 'light' ? 'bg-emerald-50 border-emerald-100' : 'bg-slate-800 border-slate-700'
                }`}>
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="text-emerald-600 w-6 h-6" />
                    <h2 className={`text-xl font-bold ${theme === 'light' ? 'text-emerald-900' : 'text-emerald-100'}`}>Personalized Wellness Blueprint</h2>
                  </div>
                  <button
                    id="reset-btn"
                    onClick={() => setView('form')}
                    className={`text-sm font-semibold underline underline-offset-4 transition-colors ${
                      theme === 'light' ? 'text-emerald-700 hover:text-emerald-900' : 'text-emerald-400 hover:text-emerald-300'
                    }`}
                  >
                    New Analysis
                  </button>
                </div>
                
                <div className={`p-8 md:p-12 prose max-w-none transition-colors ${
                  theme === 'light' ? 'prose-emerald' : 'prose-invert prose-emerald'
                }`}>
                  <div className={`markdown-body ${theme === 'dark' ? 'dark' : ''}`}>
                    <ReactMarkdown>{reportData.markdown}</ReactMarkdown>
                  </div>

                  {/* Doctor Signature */}
                  <div className={`mt-12 flex flex-col items-end border-t pt-8 transition-colors ${
                    theme === 'light' ? 'border-emerald-50' : 'border-slate-800'
                  }`}>
                    <div className={`flex items-center gap-2 font-bold italic text-xl transition-colors ${
                      theme === 'light' ? 'text-emerald-800' : 'text-emerald-400'
                    }`}>
                      <Signature className="w-6 h-6" />
                      <span>Dr. Prakriti AI</span>
                    </div>
                    <p className={`text-xs uppercase tracking-widest font-bold mt-1 transition-colors ${
                      theme === 'light' ? 'text-emerald-600' : 'text-emerald-500/60'
                    }`}>Verified Ayurvedic Intelligence</p>
                  </div>

                  {/* Pranayama Section */}
                  <div className="mt-12 p-8 bg-emerald-900 text-white rounded-3xl shadow-xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-10">
                      <Wind className="w-32 h-32" />
                    </div>
                    <div className="relative z-10">
                      <div className="flex items-center gap-3 mb-8">
                        <div className="bg-white/20 p-2 rounded-lg">
                          <Wind className="w-6 h-6" />
                        </div>
                        <h2 className="text-2xl font-bold text-white m-0 border-none">Guided Pranayama</h2>
                      </div>
                      
                      <div className="space-y-12">
                        {(Array.isArray(reportData.pranayama) ? reportData.pranayama : [reportData.pranayama]).map((technique: any, tIdx) => (
                          <div key={tIdx} className={`pb-8 ${tIdx !== (Array.isArray(reportData.pranayama) ? reportData.pranayama.length : 1) - 1 ? 'border-b border-white/10' : ''}`}>
                            <div className="mb-6">
                              <h3 className="text-emerald-300 text-xs uppercase tracking-widest font-bold mb-1">Recommended Technique {tIdx + 1}</h3>
                              <p className="text-2xl font-semibold">{technique.name}</p>
                              <div className="flex flex-wrap gap-4 mt-3">
                                <div className="flex items-center gap-2 bg-white/10 px-3 py-1.5 rounded-full">
                                  <Clock className="w-4 h-4 text-emerald-400" />
                                  <span className="text-xs font-medium text-emerald-50">{technique.duration}</span>
                                </div>
                                <div className="flex items-center gap-2 bg-white/10 px-3 py-1.5 rounded-full">
                                  <Sun className="w-4 h-4 text-emerald-400" />
                                  <span className="text-xs font-medium text-emerald-50">{technique.bestTime}</span>
                                </div>
                              </div>
                            </div>

                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                              <div>
                                <h3 className="text-emerald-300 text-xs uppercase tracking-widest font-bold mb-4">Specific Benefits</h3>
                                <div className="space-y-3">
                                  {technique.detailedBenefits ? technique.detailedBenefits.map((b: string, bIdx: number) => (
                                    <div key={bIdx} className="flex gap-3 items-center">
                                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 flex-shrink-0" />
                                      <p className="text-emerald-50 text-sm leading-relaxed">{b}</p>
                                    </div>
                                  )) : (
                                    <div className="flex gap-3 items-center">
                                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 flex-shrink-0" />
                                      <p className="text-emerald-50 text-sm leading-relaxed">{technique.benefit}</p>
                                    </div>
                                  )}
                                </div>
                              </div>

                              <div>
                                <h3 className="text-emerald-300 text-xs uppercase tracking-widest font-bold mb-4">Step-by-Step Instructions</h3>
                                <div className="space-y-4">
                                  {technique.steps.map((step: string, sIdx: number) => (
                                    <div key={sIdx} className="flex gap-4 items-start">
                                      <span className="bg-white/20 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">
                                        {sIdx + 1}
                                      </span>
                                      <p className="text-emerald-50 text-sm leading-relaxed">{step}</p>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Learn Ayurveda Section */}
                  {reportData.educationalContent && reportData.educationalContent.length > 0 && (
                    <div className={`mt-12 p-8 rounded-3xl border transition-colors ${
                      theme === 'light' ? 'bg-white border-emerald-100' : 'bg-slate-800/50 border-slate-700'
                    }`}>
                      <div className="flex items-center gap-3 mb-8">
                        <div className={`p-2 rounded-lg ${theme === 'light' ? 'bg-emerald-100 text-emerald-600' : 'bg-emerald-500/20 text-emerald-400'}`}>
                          <BookOpen className="w-6 h-6" />
                        </div>
                        <h2 className={`text-2xl font-bold m-0 border-none transition-colors ${
                          theme === 'light' ? 'text-emerald-900' : 'text-emerald-100'
                        }`}>Learn Ayurveda</h2>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {reportData.educationalContent.map((item, idx) => (
                          <div 
                            key={idx} 
                            id={item.title.toLowerCase().replace(/\s+/g, '-')}
                            className={`p-6 rounded-2xl border transition-all hover:shadow-md ${
                              theme === 'light' ? 'bg-emerald-50/30 border-emerald-100/50' : 'bg-slate-900/50 border-slate-700/50'
                            }`}
                          >
                            <div className="flex justify-between items-start mb-3">
                              <h3 className={`text-lg font-bold ${theme === 'light' ? 'text-emerald-900' : 'text-emerald-100'}`}>
                                {item.title}
                              </h3>
                              <span className={`text-[10px] uppercase tracking-widest font-bold px-2 py-1 rounded-full ${
                                theme === 'light' ? 'bg-emerald-100 text-emerald-700' : 'bg-emerald-500/20 text-emerald-400'
                              }`}>
                                {item.category}
                              </span>
                            </div>
                            <p className={`text-sm leading-relaxed ${theme === 'light' ? 'text-slate-600' : 'text-slate-400'}`}>
                              {item.description}
                            </p>
                          </div>
                        ))}
                      </div>

                      {/* Glossary Feature */}
                      <AyurvedicGlossary theme={theme} />
                    </div>
                  )}

                  {/* Charts Section */}
                  <div className={`mt-12 space-y-12 border-t pt-12 transition-colors ${
                    theme === 'light' ? 'border-emerald-50' : 'border-slate-800'
                  }`}>
                    <h2 className={`text-2xl font-bold mb-8 transition-colors ${
                      theme === 'light' ? 'text-emerald-900' : 'text-emerald-100'
                    }`}>Health Visualizations</h2>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {/* Dosha Charts */}
                      <div className={`p-6 rounded-2xl border transition-colors ${
                        theme === 'light' ? 'bg-emerald-50/50 border-emerald-100' : 'bg-slate-800/50 border-slate-700'
                      }`}>
                        <h3 className={`text-lg font-semibold mb-4 text-center transition-colors ${
                          theme === 'light' ? 'text-emerald-800' : 'text-emerald-400'
                        }`}>Dosha Distribution (Pie)</h3>
                        <div className="h-64">
                          <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                              <Pie
                                data={reportData.doshaData}
                                cx="50%"
                                cy="50%"
                                labelLine={false}
                                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                                outerRadius={80}
                                fill="#8884d8"
                                dataKey="value"
                              >
                                {reportData.doshaData.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                              </Pie>
                              <Tooltip 
                                contentStyle={{ 
                                  backgroundColor: theme === 'light' ? '#fff' : '#1e293b',
                                  border: 'none',
                                  borderRadius: '12px',
                                  boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                                  color: theme === 'light' ? '#1e293b' : '#f1f5f9'
                                }}
                                formatter={(value: number, name: string) => {
                                  const total = reportData.doshaData.reduce((acc, curr) => acc + curr.value, 0);
                                  const percent = ((value / total) * 100).toFixed(1);
                                  return [`${value} (${percent}%)`, name];
                                }}
                              />
                            </PieChart>
                          </ResponsiveContainer>
                        </div>
                      </div>

                      <div className={`p-6 rounded-2xl border transition-colors ${
                        theme === 'light' ? 'bg-emerald-50/50 border-emerald-100' : 'bg-slate-800/50 border-slate-700'
                      }`}>
                        <h3 className={`text-lg font-semibold mb-4 text-center transition-colors ${
                          theme === 'light' ? 'text-emerald-800' : 'text-emerald-400'
                        }`}>Dosha Analysis (Bar)</h3>
                        <div className="h-64">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={reportData.doshaData}>
                              <CartesianGrid strokeDasharray="3 3" stroke={theme === 'light' ? '#e2e8f0' : '#334155'} />
                              <XAxis dataKey="name" stroke={theme === 'light' ? '#64748b' : '#94a3b8'} />
                              <YAxis stroke={theme === 'light' ? '#64748b' : '#94a3b8'} />
                              <Tooltip 
                                contentStyle={{ 
                                  backgroundColor: theme === 'light' ? '#fff' : '#1e293b',
                                  border: 'none',
                                  borderRadius: '12px',
                                  boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                                  color: theme === 'light' ? '#1e293b' : '#f1f5f9'
                                }}
                                formatter={(value: number) => [`${value} Units`, 'Score']}
                              />
                              <Bar dataKey="value" fill={COLORS[0]} radius={[4, 4, 0, 0]}>
                                {reportData.doshaData.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                              </Bar>
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      </div>

                      {/* Location Disease Prediction */}
                      <div className={`p-6 rounded-2xl border md:col-span-2 transition-colors ${
                        theme === 'light' ? 'bg-emerald-50/50 border-emerald-100' : 'bg-slate-800/50 border-slate-700'
                      }`}>
                        <h3 className={`text-lg font-semibold mb-4 text-center transition-colors ${
                          theme === 'light' ? 'text-emerald-800' : 'text-emerald-400'
                        }`}>Disease Prevalence in {formData.location}</h3>
                        <div className="h-64">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={reportData.locationDiseaseData} layout="vertical">
                              <CartesianGrid strokeDasharray="3 3" stroke={theme === 'light' ? '#e2e8f0' : '#334155'} />
                              <XAxis type="number" stroke={theme === 'light' ? '#64748b' : '#94a3b8'} />
                              <YAxis dataKey="name" type="category" width={150} stroke={theme === 'light' ? '#64748b' : '#94a3b8'} />
                              <Tooltip 
                                contentStyle={{ 
                                  backgroundColor: theme === 'light' ? '#fff' : '#1e293b',
                                  border: 'none',
                                  borderRadius: '12px',
                                  boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                                  color: theme === 'light' ? '#1e293b' : '#f1f5f9'
                                }}
                                formatter={(value: number) => [`${value}% Prevalence`, 'Value']}
                              />
                              <Bar dataKey="value" fill={COLORS[1]} radius={[0, 4, 4, 0]}>
                                {reportData.locationDiseaseData.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[(index + 1) % COLORS.length]} />
                                ))}
                              </Bar>
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      </div>

                      {/* Diet & Medicine Pie Charts */}
                      <div className={`p-6 rounded-2xl border transition-colors ${
                        theme === 'light' ? 'bg-emerald-50/50 border-emerald-100' : 'bg-slate-800/50 border-slate-700'
                      }`}>
                        <h3 className={`text-lg font-semibold mb-4 text-center transition-colors ${
                          theme === 'light' ? 'text-emerald-800' : 'text-emerald-400'
                        }`}>Recommended Diet Distribution</h3>
                        <div className="h-64">
                          <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                              <Pie
                                data={reportData.dietData}
                                cx="50%"
                                cy="50%"
                                labelLine={false}
                                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                                outerRadius={80}
                                fill="#8884d8"
                                dataKey="value"
                              >
                                {reportData.dietData.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                              </Pie>
                              <Tooltip 
                                contentStyle={{ 
                                  backgroundColor: theme === 'light' ? '#fff' : '#1e293b',
                                  border: 'none',
                                  borderRadius: '12px',
                                  boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                                  color: theme === 'light' ? '#1e293b' : '#f1f5f9'
                                }}
                                formatter={(value: number, name: string) => {
                                  const total = reportData.dietData.reduce((acc, curr) => acc + curr.value, 0);
                                  const percent = ((value / total) * 100).toFixed(1);
                                  return [`${value} Portion (${percent}%)`, name];
                                }}
                              />
                            </PieChart>
                          </ResponsiveContainer>
                        </div>
                      </div>

                      <div className={`p-6 rounded-2xl border transition-colors ${
                        theme === 'light' ? 'bg-emerald-50/50 border-emerald-100' : 'bg-slate-800/50 border-slate-700'
                      }`}>
                        <h3 className={`text-lg font-semibold mb-4 text-center transition-colors ${
                          theme === 'light' ? 'text-emerald-800' : 'text-emerald-400'
                        }`}>Herbal Medicine Distribution</h3>
                        <div className="h-64">
                          <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                              <Pie
                                data={reportData.medicineData}
                                cx="50%"
                                cy="50%"
                                labelLine={false}
                                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                                outerRadius={80}
                                fill="#8884d8"
                                dataKey="value"
                              >
                                {reportData.medicineData.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                              </Pie>
                              <Tooltip 
                                contentStyle={{ 
                                  backgroundColor: theme === 'light' ? '#fff' : '#1e293b',
                                  border: 'none',
                                  borderRadius: '12px',
                                  boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                                  color: theme === 'light' ? '#1e293b' : '#f1f5f9'
                                }}
                                formatter={(value: number, name: string) => {
                                  const total = reportData.medicineData.reduce((acc, curr) => acc + curr.value, 0);
                                  const percent = ((value / total) * 100).toFixed(1);
                                  return [`${value} Focus (${percent}%)`, name];
                                }}
                              />
                            </PieChart>
                          </ResponsiveContainer>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="text-center mb-8">
                <p className={`text-lg font-serif italic transition-colors ${
                  theme === 'light' ? 'text-emerald-800/60' : 'text-emerald-400/40'
                }`}>
                  "Take care, be happy. Life is too small, make others happy."
                </p>
              </div>

              <div className="flex justify-center gap-4">
                <button
                  id="print-btn"
                  onClick={() => window.print()}
                  className={`px-6 py-3 rounded-xl font-bold transition-colors flex items-center gap-2 border ${
                    theme === 'light' 
                      ? 'bg-white border-emerald-200 text-emerald-700 hover:bg-emerald-50' 
                      : 'bg-slate-800 border-slate-700 text-emerald-400 hover:bg-slate-700'
                  }`}
                >
                  <FileText className="w-5 h-5" />
                  Save as PDF
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <footer className={`max-w-4xl mx-auto py-12 px-4 text-center border-t mt-12 transition-colors ${
        theme === 'light' ? 'text-gray-500 border-emerald-50' : 'text-slate-500 border-slate-800'
      }`}>
        <p className={`text-lg font-serif italic mb-6 transition-colors ${
          theme === 'light' ? 'text-emerald-800/60' : 'text-emerald-400/40'
        }`}>
          "Take care, be happy. Life is too small, make others happy."
        </p>
        <p className="text-sm mb-2">© 2026 Prakriti AI. All rights reserved.</p>
        <p className="text-xs italic">Disclaimer: This AI-generated report is for informational purposes only. Always consult with a qualified healthcare professional before starting any new health regimen.</p>
      </footer>
    </div>
  );
}
